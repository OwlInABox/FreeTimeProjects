/*
 * setup.h
 *
 * Created: 21/02/2020 10:14:32
 *  Author: nico835t
 */ 


#ifndef SETUP_H_
#define SETUP_H_
void interruptSetup(void);
void registerSetup(void);





#endif /* SETUP_H_ */